#!/usr/bin/env python3

import numpy as np
import copy
import rospy

# ===== Settings =====
motion_noise = [0.1, 0.05]      # [std dev of velocity, std dev of angular velocity]
measurement_noise = [0.2, 0.1]  # [std dev of range, std dev of bearing]
dt = 0.1    # Time step for motion model

# ===== Helper Functions =====
def wrap_angle(angle):
    while angle > np.pi:
        angle -= 2.0 * np.pi
    while angle < -np.pi:
        angle += 2.0 * np.pi
    return angle

def compute_control_from_poses(prev_pose, curr_pose, dt):
    """Compute control commands from consecutive poses"""
    if prev_pose is None or curr_pose is None:
        return [0.0, 0.0]
    
    # Compute linear velocity
    dx = curr_pose[0] - prev_pose[0]
    dy = curr_pose[1] - prev_pose[1]
    v = np.sqrt(dx**2 + dy**2) / dt
    
    # Compute angular velocity
    dtheta = wrap_angle(curr_pose[2] - prev_pose[2])
    w = dtheta / dt
    
    return [v, w]

def measurement_model(pose, landmark):
    dx = landmark[0] - pose[0]
    dy = landmark[1] - pose[1]
    r = np.hypot(dx, dy)
    bearing = wrap_angle(np.arctan2(dy, dx) - pose[2])
    return np.array([r, bearing])

def compute_jacobian(pose, landmark):
    dx = landmark[0] - pose[0]
    dy = landmark[1] - pose[1]
    q = dx**2 + dy**2
    sqrt_q = np.sqrt(q)
    H = np.array([
        [dx / sqrt_q, dy / sqrt_q],
        [-dy / q, dx / q]
    ])
    return H, q

def motion_model(pose, control):
    v, w = control
    
    v_noise = np.random.normal(0, motion_noise[0] * max(abs(v), 0.1))
    w_noise = np.random.normal(0, motion_noise[1] * max(abs(w), 0.01))
    v += v_noise
    w += w_noise
    
    if abs(w) > 1e-6:  # If angular velocity is significant
        # Use circular motion model
        theta_new = wrap_angle(pose[2] + w * dt)
        theta_mid = (pose[2] + theta_new) / 2
        
        distance = v * dt
        x = pose[0] + distance * np.cos(theta_mid)
        y = pose[1] + distance * np.sin(theta_mid)
    else:
        # Use linear motion model
        x = pose[0] + v * np.cos(pose[2]) * dt
        y = pose[1] + v * np.sin(pose[2]) * dt
        theta_new = pose[2]
    
    return np.array([x, y, theta_new])

def ekf_update(mu, sigma, z, pose):
    z_hat = measurement_model(pose, mu)
    H, q = compute_jacobian(pose, mu)
    R = np.diag(measurement_noise)**2
    S = H @ sigma @ H.T + R
    K = sigma @ H.T @ np.linalg.inv(S)
    innovation = z - z_hat
    innovation[1] = wrap_angle(innovation[1])
    if abs(innovation[1]) > np.radians(25):     # Changed from 60 to 25, improved some how
    # Skip update — too much angular disagreement
        return mu, sigma, 1e-10
    
    # Calculate Mahalanobis distance of the innovation
    mahalanobis = innovation.T @ np.linalg.inv(S) @ innovation
    if mahalanobis > 9.0:  # ~3 standard deviations
        return mu, sigma, 1e-10  # reject outlier update

    mu = mu + K @ innovation
    sigma = (np.eye(2) - K @ H) @ sigma
    prob = np.exp(-0.5 * innovation.T @ np.linalg.inv(S) @ innovation) \
           / np.sqrt((2 * np.pi)**2 * np.linalg.det(S))
    return mu, sigma, prob

def validate_landmark_transformation(robot_pose, relative_pos, absolute_pos):

    x_r, y_r, theta_r = robot_pose
    x_rel, z_rel = relative_pos  # x=lateral, z=depth
    x_abs, y_abs = absolute_pos
    
    # Recalculate the transformed position
    cos_theta = np.cos(theta_r)
    sin_theta = np.sin(theta_r)
    x_calc = x_r + x_rel * cos_theta - z_rel * sin_theta
    y_calc = y_r + x_rel * sin_theta + z_rel * cos_theta
    
    error = np.sqrt((x_calc - x_abs)**2 + (y_calc - y_abs)**2)
    
    return error < 1e-6, (x_calc, y_calc), error

# ===== Enhanced Resampling Functions =====
def normalize_weights(particles):
    """Normalize particle weights"""
    weights = np.array([p['weight'] for p in particles])
    weights += 1e-300
    total_weight = np.sum(weights)
    
    if total_weight == 0:
        for p in particles:
            p['weight'] = 1.0 / len(particles)
    else:
        for i, p in enumerate(particles):
            p['weight'] = weights[i] / total_weight
    return particles

def low_variance_resampling(weights, equal_weights, num_particles):
    """Low variance resampling algorithm"""
    indices = []
    r = np.random.uniform(0, 1.0/num_particles)
    c = weights[0]
    i = 0
    
    for m in range(num_particles):
        u = r + m * (1.0/num_particles)
        while u > c:
            i += 1
            if i >= len(weights):
                i = len(weights) - 1
                break
            c += weights[i]
        indices.append(i)
    
    return indices

def stratified_resampling(weights, num_particles):
    """Stratified resampling algorithm"""
    indices = []
    cumsum = np.cumsum(weights)
    
    for i in range(num_particles):
        # Generate random number in stratum
        u = (i + np.random.uniform(0, 1)) / num_particles
        # Find corresponding index
        index = np.searchsorted(cumsum, u)
        indices.append(min(index, len(weights) - 1))
    
    return indices

def resample(particles, resample_method="low variance"):
    """Enhanced resampling function with effective particle number check"""
    
    # Normalize weights
    particles = normalize_weights(particles)
    weights = np.array([p['weight'] for p in particles])
    
    # Find highest weight particle index before resampling
    highest_weight_index = np.argmax(weights)
    
    # Calculate effective particle number
    Neff = 1.0 / np.sum(np.square(weights)) if np.sum(np.square(weights)) > 0 else 0
    equal_weights = np.full_like(weights, 1.0 / len(particles))
    Neff_maximum = 1.0 / np.sum(np.square(equal_weights))
    
    new_highest_weight_index = highest_weight_index
    
    # Resample if Neff is too low - particles are not representative of posterior
    if Neff < Neff_maximum / 2:
        rospy.logdebug(f"Resampling triggered: Neff={Neff:.2f} < {Neff_maximum/2:.2f}")
        
        if resample_method == "low variance":
            indices = low_variance_resampling(weights, equal_weights, len(particles))
        elif resample_method == "Stratified":
            indices = stratified_resampling(weights, len(particles))
        else:
            # Fallback to simple random resampling
            indices = np.random.choice(len(particles), size=len(particles), p=weights)
        
        # Create new particle set
        particles_copy = copy.deepcopy(particles)
        for i in range(len(indices)):
            particles[i]['pose'] = particles_copy[indices[i]]['pose'].copy()
            particles[i]['map'] = copy.deepcopy(particles_copy[indices[i]]['map'])
            particles[i]['weight'] = 1.0 / len(particles)  # Reset weights
            
            # Track new index of highest weight particle
            if highest_weight_index == indices[i]:
                new_highest_weight_index = i
    
    return particles, new_highest_weight_index