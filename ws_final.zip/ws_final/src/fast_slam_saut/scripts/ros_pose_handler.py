#!/usr/bin/env python3

import numpy as np
import rospy
from nav_msgs.msg import Odometry
import threading

class ROSPoseHandler:
    def __init__(self):
        self.current_pose = None
        self.pose_lock = threading.Lock()
        self.last_update_time = None
        
        # Subscribe only to /pose topic
        rospy.Subscriber('/pose', Odometry, self.pose_callback)
        
        rospy.loginfo("Subscribed to /pose topic")
    
    def pose_callback(self, msg):
        with self.pose_lock:
            x = msg.pose.pose.position.x
            y = msg.pose.pose.position.y

            quat = msg.pose.pose.orientation
            theta = self.quaternion_to_euler(quat.x, quat.y, quat.z, quat.w)

            self.current_pose = np.array([x, y, theta])
            self.last_update_time = rospy.Time.now()

    def quaternion_to_euler(self, x, y, z, w):
        """Convert quaternion to euler angle (yaw)"""
        siny_cosp = 2 * (w * z + x * y)
        cosy_cosp = 1 - 2 * (y * y + z * z)
        yaw = np.arctan2(siny_cosp, cosy_cosp)
        return yaw
    
    def get_pose(self):
        with self.pose_lock:
            return self.current_pose.copy() if self.current_pose is not None else None
    
    def is_pose_available(self):
        with self.pose_lock:
            if self.last_update_time is None:
                return False
            return (rospy.Time.now() - self.last_update_time).to_sec() < 1.0