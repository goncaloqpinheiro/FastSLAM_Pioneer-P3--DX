#!/usr/bin/env python3

import numpy as np
import copy
import rospy
from geometry_msgs.msg import PoseStamped
from nav_msgs.msg import Odometry
from geometry_msgs.msg import PoseArray
from std_msgs.msg import Int32MultiArray

import threading
import time

from ros_pose_handler import ROSPoseHandler
from ros_marker_handler import ROSMarkerHandler
from rviz_publisher import RVizPublisher
from helper_functions import *

# ===== Simulation Settings =====
np.random.seed(42)
num_steps = 1000
num_particles = 600
dt = 0.1

# ===== Noise Settings =====
motion_noise = [0.1, 0.05]
measurement_noise = [0.2, 0.1]

resample_method = "low variance"

def main():
    # Initialize ROS
    rospy.init_node('fastslam_ros', anonymous=True)
    rospy.loginfo("FastSLAM ROS Node Started")

    # Initialize ROS handlers
    pose_handler = ROSPoseHandler()
    marker_handler = ROSMarkerHandler(pose_handler)
    rviz_publisher = RVizPublisher()

    rospy.loginfo("Waiting for pose data...")
    while not pose_handler.is_pose_available() and not rospy.is_shutdown():
        rospy.sleep(0.1)

    if rospy.is_shutdown():
        return

    rospy.loginfo("Received initial pose, starting FastSLAM...")

    # Initialize with first pose
    initial_pose = pose_handler.get_pose()
    pose = initial_pose.copy()
    prev_pose = initial_pose.copy()

    true_trajectory = [pose.copy()]
    estimated_trajectory = []
    observed_landmarks_dict = {}

    particles = [{
        'pose': pose.copy(),
        'map': {},
        'weight': 1.0
    } for _ in range(num_particles)]

    highest_weight_particle_index = 0
    step = 0
    rate = rospy.Rate(10)

    rospy.loginfo("Starting main FastSLAM loop...")

    while not rospy.is_shutdown() and step < num_steps:
        current_ros_pose = pose_handler.get_pose()

        if current_ros_pose is None:
            rospy.logwarn("No pose data available, skipping step")
            rate.sleep()
            continue

        control = compute_control_from_poses(prev_pose, current_ros_pose, dt)
        pose = current_ros_pose.copy()
        true_trajectory.append(pose.copy())

        current_landmarks = marker_handler.get_absolute_landmarks()

        if step % 100 == 0 and current_landmarks:
            rospy.loginfo(f"Step {step}: Robot pose = ({pose[0]:.2f}, {pose[1]:.2f}, {np.degrees(pose[2]):.1f}°)")
            for lm_id, lm_pos in current_landmarks:
                rospy.loginfo(f"  Landmark {lm_id}: global position = ({lm_pos[0]:.2f}, {lm_pos[1]:.2f})")

        for lm_id, lm_pos in current_landmarks:
            observed_landmarks_dict[lm_id] = lm_pos

        for p in particles:
            p['pose'] = motion_model(p['pose'], control)

            for lm_id, landmark_pos in current_landmarks:
                dx = landmark_pos[0] - p['pose'][0]
                dy = landmark_pos[1] - p['pose'][1]
                distance = np.hypot(dx, dy)
                bearing = wrap_angle(np.arctan2(dy, dx) - p['pose'][2])
                z = measurement_model(p['pose'], landmark_pos)

                if lm_id not in p['map']:
                    r, b = z
                    lx = p['pose'][0] + r * np.cos(b + p['pose'][2])
                    ly = p['pose'][1] + r * np.sin(b + p['pose'][2])
                    p['map'][lm_id] = {'mu': np.array([lx, ly]), 'sigma': np.eye(2) * 1.0}
                else:
                    mu, sigma = p['map'][lm_id]['mu'], p['map'][lm_id]['sigma']
                    mu, sigma, prob = ekf_update(mu, sigma, z, p['pose'])
                    p['map'][lm_id]['mu'] = mu
                    p['map'][lm_id]['sigma'] = sigma
                    p['weight'] *= prob

        particles, highest_weight_particle_index = resample(particles, resample_method)

        best_particle = particles[highest_weight_particle_index]
        estimated_trajectory.append(best_particle['pose'].copy())

        # RViz Publishing
        if step % 2 == 0:
            particle_subsample = particles[::max(1, len(particles)//50)]
            rviz_publisher.publish_particles(particle_subsample)

            if best_particle['map']:
                rviz_publisher.publish_landmarks(best_particle['map'])
                rviz_publisher.publish_uncertainty_ellipses(best_particle['map'])

            rviz_publisher.publish_trajectory(estimated_trajectory)
            rviz_publisher.publish_true_trajectory(true_trajectory)
            rviz_publisher.publish_robot_pose(best_particle['pose'])

        prev_pose = current_ros_pose.copy()
        step += 1

        if step % 50 == 0:
            rospy.loginfo(f"FastSLAM step {step}/{num_steps} - Landmarks observed: {len(observed_landmarks_dict)}")

        rate.sleep()

    rospy.loginfo("FastSLAM simulation completed")

    best_particle = particles[highest_weight_particle_index]
    print("\n=== Final Map Estimate from Best Particle ===")
    for lm_id, lm in best_particle['map'].items():
        mu = lm['mu']
        print(f"Landmark {lm_id}:")
        print(f"  → Estimated: [{mu[0]:.2f}, {mu[1]:.2f}]")

    print(f"Total landmarks mapped: {len(best_particle['map'])}")
    print(f"Total unique landmarks observed: {len(observed_landmarks_dict)}")

    rospy.loginfo("FastSLAM completed. RViz visualization will continue until node is stopped.")

    final_rate = rospy.Rate(1)
    while not rospy.is_shutdown():
        if best_particle['map']:
            rviz_publisher.publish_landmarks(best_particle['map'])
            rviz_publisher.publish_uncertainty_ellipses(best_particle['map'])
        rviz_publisher.publish_trajectory(estimated_trajectory)
        rviz_publisher.publish_robot_pose(best_particle['pose'])
        final_rate.sleep()

    rviz_publisher.clear_markers()

if __name__ == '__main__':
    try:
        main()
    except rospy.ROSInterruptException:
        rospy.loginfo("FastSLAM node interrupted")
    except KeyboardInterrupt:
        rospy.loginfo("FastSLAM node stopped by user")
