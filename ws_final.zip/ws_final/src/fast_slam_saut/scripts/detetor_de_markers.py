#!/usr/bin/env python3
import rospy
from sensor_msgs.msg import Image
from std_msgs.msg import Int32MultiArray
from geometry_msgs.msg import Pose, PoseArray
from cv_bridge import CvBridge
import cv2
import numpy as np
import math
import matplotlib.pyplot as plt
import tf.transformations

# === Load calibration data ===
data = np.load("/home/ubuntu/ws_final/src/fast_slam_saut/scripts/logitech.npz")
camera_matrix = data['camera_matrix']
dist_coeffs = data['dist_coeffs']

# === Marker setup ===
marker_length = 0.18  # 18 cm
aruco_dict = cv2.aruco.getPredefinedDictionary(cv2.aruco.DICT_5X5_100)
parameters = cv2.aruco.DetectorParameters_create()

bridge = CvBridge()
marker_positions = []
pose_pub = None
id_pub = None
X_offset_in_robot_frame = 0.07
Z_offset_in_robot_frame = 0.22  

def euclidean_distance(tvec):
    x, y, z = tvec
    return math.sqrt(x**2 + y**2 + z**2)

def get_euler_angles(rvec):
    R, _ = cv2.Rodrigues(rvec)
    sy = math.sqrt(R[0, 0] ** 2 + R[1, 0] ** 2)
    singular = sy < 1e-6

    if not singular:
        x = math.atan2(R[2, 1], R[2, 2])
        y = math.atan2(-R[2, 0], sy)
        z = math.atan2(R[1, 0], R[0, 0])
    else:
        x = math.atan2(-R[1, 2], R[1, 1])
        y = math.atan2(-R[2, 0], sy)
        z = 0

    return np.degrees([x, y, z])

def draw_cube(frame, rvec, tvec, camera_matrix, dist_coeffs):
    cube_points = np.float32([
        [0, 0, 0], [marker_length, 0, 0],
        [marker_length, marker_length, 0], [0, marker_length, 0],
        [0, 0, -marker_length], [marker_length, 0, -marker_length],
        [marker_length, marker_length, -marker_length], [0, marker_length, -marker_length]
    ])
    imgpts, _ = cv2.projectPoints(cube_points, rvec, tvec, camera_matrix, dist_coeffs)
    imgpts = np.int32(imgpts).reshape(-1, 2)

    frame = cv2.drawContours(frame, [imgpts[:4]], -1, (0,255,0), 2)
    for i in range(4):
        frame = cv2.line(frame, tuple(imgpts[i]), tuple(imgpts[i+4]), (255,0,0), 2)
    frame = cv2.drawContours(frame, [imgpts[4:]], -1, (0,0,255), 2)
    return frame

def tf_quaternion_from_matrix(R):
    rot_matrix = np.eye(4)
    rot_matrix[:3, :3] = R
    return tf.transformations.quaternion_from_matrix(rot_matrix)

def transform_camera_to_robot(translation_vector):
    R_cam_to_robot = np.array([
        [0, 0, 1],
        [0, 1, 0],
        [-1, 0, 0]
    ])
    T_cam_to_robot = np.array([
    X_offset_in_robot_frame,  # lateral (right is +)
    0,
    Z_offset_in_robot_frame   # forward is + 
    ])
    translation_vector_hom = np.append(translation_vector, [1])
    transformation_matrix = np.eye(4)
    transformation_matrix[:3, :3] = R_cam_to_robot
    transformation_matrix[:3, 3] = T_cam_to_robot
    translation_vector_robot_hom = np.dot(transformation_matrix, translation_vector_hom)
    return translation_vector_robot_hom[:3]


def image_callback(msg):
    global marker_positions, pose_pub, id_pub

    try:
        frame = bridge.imgmsg_to_cv2(msg, desired_encoding='bgr8')
    except Exception as e:
        rospy.logerr(f"cv_bridge error: {e}")
        return

    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    corners, ids, _ = cv2.aruco.detectMarkers(gray, aruco_dict, parameters=parameters)

    pose_array = PoseArray()
    pose_array.header.stamp = rospy.Time.now()
    pose_array.header.frame_id = "camera"

    id_array = Int32MultiArray()

    if ids is not None:
        cv2.aruco.drawDetectedMarkers(frame, corners, ids)
        rvecs, tvecs, _ = cv2.aruco.estimatePoseSingleMarkers(corners, marker_length, camera_matrix, dist_coeffs)

        for i in range(len(ids)):
            rvec, tvec = rvecs[i], tvecs[i]

            # Flatten tvec to 1D if needed (shape should be (3,))
            tvec_flat = tvec[0]

            # print(f" Distance: {distance2:.2f} m")

            # Apply transformation
            tvec_robot = transform_camera_to_robot(tvec_flat)

            # Draw axis and cube
            cv2.aruco.drawAxis(frame, camera_matrix, dist_coeffs, rvec, tvec, 0.01)
            frame = draw_cube(frame, rvec, tvec, camera_matrix, dist_coeffs)

            marker_positions.append({'id': int(ids[i][0]), 'position': tvec_robot})
            id_array.data.append(int(ids[i][0]))

            # Convert rotation to quaternion
            R, _ = cv2.Rodrigues(rvec)
            quat = tf_quaternion_from_matrix(R)

            pose = Pose()
            pose.position.x = tvec_robot[0]
            pose.position.y = tvec_robot[1]
            pose.position.z = tvec_robot[2]
            pose.orientation.x = quat[0]
            pose.orientation.y = quat[1]
            pose.orientation.z = quat[2]
            pose.orientation.w = quat[3]

            pose_array.poses.append(pose)
            
            # Visualization
            distance = euclidean_distance(tvec_robot)
            pitch, yaw, roll = get_euler_angles(rvec)
            c = tuple(np.int32(corners[i][0][0]))
            text = f"ID:{ids[i][0]} | Dist:{distance*100:.1f}cm | Pitch:{pitch:.1f}° Yaw:{yaw:.1f}° Roll:{roll:.1f}°"
            
            cv2.putText(frame, text, (c[0], c[1] - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)


    pose_pub.publish(pose_array)
    id_pub.publish(id_array)

    cv2.imshow("Pose Estimation", frame)
    cv2.waitKey(1)

def plot_positions():
    if marker_positions:
        positions_by_id = {i: [] for i in range(5)}
        for entry in marker_positions:
            marker_id = entry['id']
            if marker_id in positions_by_id:
                positions_by_id[marker_id].append(entry['position'])

        color_map = {
            0: 'red',
            1: 'green',
            2: 'blue',
            3: 'orange',
            4: 'purple'
        }

        plt.figure(figsize=(8, 6))
        for marker_id, positions in positions_by_id.items():
            if positions:
                pos_array = np.array(positions)
                plt.scatter(pos_array[:, 0], pos_array[:, 2], c=color_map[marker_id], label=f"ID {marker_id}")
                for x, z in zip(pos_array[:, 0], pos_array[:, 2]):
                    plt.annotate(f"{marker_id}", (x, z), textcoords="offset points", xytext=(0,5), ha='center')

        plt.axhline(0, color='gray', linestyle='--')
        plt.axvline(0, color='gray', linestyle='--')
        plt.xlabel('X (meters) – left/right')
        plt.ylabel('Z (meters) – forward')
        plt.title('2D Marker Position Relative to Camera (Top-Down View)')
        plt.legend()
        plt.grid(True)
        plt.axis('equal')
        plt.show()
    else:
        print("No marker positions recorded.")

def main():
    global pose_pub, id_pub
    rospy.init_node('aruco_pose_estimation', anonymous=True)
    rospy.Subscriber("/camera/image_raw", Image, image_callback)
    pose_pub = rospy.Publisher("/markers_pose", PoseArray, queue_size=10)
    id_pub = rospy.Publisher("/markers_id", Int32MultiArray, queue_size=10)
    #rospy.on_shutdown(plot_positions)
    rospy.spin()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    main()
