#!/usr/bin/env python3

import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as patches
import copy
import rospy
from geometry_msgs.msg import PoseStamped
from nav_msgs.msg import Odometry
from geometry_msgs.msg import PoseArray
from std_msgs.msg import Int32MultiArray

import threading
import time

from ros_pose_handler import ROSPoseHandler
from ros_marker_handler import ROSMarkerHandler
from helper_functions import *

# ===== Simulation Settings =====
num_steps = 450  # Number of steps in the simulation
num_particles = 500  # Number of particles in the FastSLAM algorithm
dt = 0.1    # Time step for motion model

## Ground truth circle
# gt_landmarks = np.array([
#     [1.0, 0],
#     [-0.2, -2.8],
#     [-1, -2],
#     [-0.7, 1],
#     [-0.4, -5.1]
# ])


## Ground truth L trajectory
gt_landmarks = np.array([
    [1.3, 0.5],
    [2.5, -0.6],
    [3.7, 0.4],
    [4.9,-0.9],
    [4.4, -2.1]
])

# ===== Settings =====
motion_noise = [0.1, 0.05]    # [std dev of velocity, std dev of angular velocity]
measurement_noise = [0.2, 0.1]  # [std dev of range, std dev of bearing]


resample_method = "low variance"  # Options: "low variance", "Stratified"

def plot_final_map(best_particle, observed_landmarks_dict):
    fig2, ax2 = plt.subplots(figsize=(8, 8))
    ax2.set_title("Final Map Estimate (Best Particle)")
    ax2.set_xlim(-5, 5)
    ax2.set_ylim(0, 30)
    ax2.grid(True)



    # Plot estimated landmarks with uncertainty ellipses
    for idx, lm in best_particle['map'].items():
        mu = lm['mu']
        sigma = lm['sigma']

        # Plot estimated position
        ax2.scatter(mu[0], mu[1], c='green', marker='x', s=100,
                   label='Estimated Landmark' if idx == list(best_particle['map'].keys())[0] else "")

        # Plot uncertainty ellipse
        vals, vecs = np.linalg.eigh(sigma)
        angle = np.degrees(np.arctan2(*vecs[:,0][::-1]))
        width, height = 6 * np.sqrt(vals)  # 3-sigma ellipse (covers 99.7% of the uncertainty)
        ellipse = plt.matplotlib.patches.Ellipse(mu, width, height, angle=angle, 
                                               alpha=0.3, color='green')
        ax2.add_patch(ellipse)

        # Label landmarks
        ax2.text(mu[0], mu[1] + 0.2, f"Est ID {idx}", color='black', fontsize=8, ha='center')

    ax2.legend()
    plt.tight_layout()
    plt.savefig("final_map_output.png")
    plt.show()

def compute_kabsch_alignment(A, B):
    """
    A: Nx2 matrix of estimated landmark positions
    B: Nx2 matrix of ground-truth landmark positions
    Returns: aligned A, rotation matrix R, and translation vector t
    """
    assert A.shape == B.shape

    centroid_A = np.mean(A, axis=0)
    centroid_B = np.mean(B, axis=0)

    AA = A - centroid_A
    BB = B - centroid_B

    H = AA.T @ BB
    U, S, Vt = np.linalg.svd(H)
    R = Vt.T @ U.T

    if np.linalg.det(R) < 0:
        Vt[1,:] *= -1
        R = Vt.T @ U.T

    t = centroid_B - R @ centroid_A

    A_aligned = (R @ A.T).T + t
    return A_aligned, R, t


# ===== MAIN FUNCTION =====
def main():
    # Initialize ROS
    rospy.init_node('fastslam_ros', anonymous=True)
    rospy.loginfo("FastSLAM ROS Node Started")
    
    # Initialize ROS pose handler
    pose_handler = ROSPoseHandler()
    marker_handler = ROSMarkerHandler(pose_handler)

    # Wait for initial pose
    rospy.loginfo("Waiting for pose data...")
    while not pose_handler.is_pose_available() and not rospy.is_shutdown():
        rospy.sleep(0.1)
    
    if rospy.is_shutdown():
        return
    
    rospy.loginfo("Received initial pose, starting FastSLAM...")
    
    # Initialize with first pose
    initial_pose = pose_handler.get_pose()
    pose = initial_pose.copy()
    prev_pose = initial_pose.copy()
    
    true_trajectory = [pose.copy()]
    estimated_trajectory = []
    observed_landmarks_dict = {}  # Store observed landmarks as {id: position}
    
    # Initialize particles
    particles = [{
        'pose': pose.copy(),
        'map': {},
        'weight': 1.0
    } for _ in range(num_particles)]
    
    # Track highest weight particle
    highest_weight_particle_index = 0
    
    # ===== Plot Setup =====
    plt.ion()  # Interactive mode
    fig, ax = plt.subplots(figsize=(12, 10))
    ax.set_xlim(-2, 12)
    ax.set_ylim(-2, 12)
    ax.set_title("FastSLAM with Pioneer")
    ax.grid(True)
    gt_landmark_plot = ax.scatter(*zip(*gt_landmarks), c='red', marker='o', s=100, label='Ground Truth Landmarks')
    
    true_traj_line, = ax.plot([], [], 'b-', label='Odometry Trajectory', linewidth=2)
    est_traj_line, = ax.plot([], [], 'green', label='Estimated Trajectory', linewidth=2)
    robot_dot = ax.scatter([], [], c='blue', s=150, label='Robot')
    particle_plot = ax.scatter([], [], c='gray', s=10, alpha=0.5, label='Particles')
    observed_landmarks = ax.scatter([], [], c='black', s=80, marker='x', 
                                  label='Observed by Best Particle')
    ax.legend()
    plt.show()
    
    # ===== Main Loop =====
    step = 0
    rate = rospy.Rate(100)  # 10 Hz
    
    rospy.loginfo("Starting main FastSLAM loop...")
    
    while not rospy.is_shutdown() and step < num_steps:
        # Get current pose from ROS
        current_ros_pose = pose_handler.get_pose()
        
        if current_ros_pose is None:
            rospy.logwarn("No pose data available, skipping step")
            rate.sleep()
            continue
        
        # Compute control from pose difference
        control = compute_control_from_poses(prev_pose, current_ros_pose, dt)

        # Update true pose (from ROS)
        pose = current_ros_pose.copy()
        true_trajectory.append(pose.copy())
        
        # Get current landmark observations
        current_landmarks = marker_handler.get_absolute_landmarks()
        
        # Debug: Log landmark transformations occasionally
        if step % 100 == 0 and current_landmarks:
            rospy.loginfo(f"Step {step}: Robot pose = ({pose[0]:.2f}, {pose[1]:.2f}, {np.degrees(pose[2]):.1f}°)")
            for lm_id, lm_pos in current_landmarks:
                rospy.loginfo(f"  Landmark {lm_id}: global position = ({lm_pos[0]:.2f}, {lm_pos[1]:.2f})")
        
        # Update observed landmarks dictionary
        for lm_id, lm_pos in current_landmarks:
            observed_landmarks_dict[lm_id] = lm_pos
        
        # Update particles
        for p in particles:
            p['pose'] = motion_model(p['pose'], control)
            
            # Process real landmark observations
            for lm_id, landmark_pos in current_landmarks:
                dx = landmark_pos[0] - p['pose'][0]
                dy = landmark_pos[1] - p['pose'][1]
                distance = np.hypot(dx, dy)
                bearing = wrap_angle(np.arctan2(dy, dx) - p['pose'][2])
                in_fov = True
                in_range = True

                if in_fov and in_range:
                    z = measurement_model(p['pose'], landmark_pos)
                    
                    if lm_id not in p['map']:
                        # Initialize new landmark
                        r, b = z
                        lx = p['pose'][0] + r * np.cos(b + p['pose'][2])
                        ly = p['pose'][1] + r * np.sin(b + p['pose'][2])
                        p['map'][lm_id] = {'mu': np.array([lx, ly]), 'sigma': np.eye(2) * 1.0}
                    else:
                        # Update existing landmark
                        mu, sigma = p['map'][lm_id]['mu'], p['map'][lm_id]['sigma']
                        mu, sigma, prob = ekf_update(mu, sigma, z, p['pose'])
                        p['map'][lm_id]['mu'] = mu
                        p['map'][lm_id]['sigma'] = sigma
                        p['weight'] *= prob

        # Enhanced resampling with effective particle number check
        particles, highest_weight_particle_index = resample(particles, resample_method)
        
        # Get best particle for visualization
        best_particle = particles[highest_weight_particle_index]
        estimated_trajectory.append(best_particle['pose'].copy())

        # Update visualization
        if len(true_trajectory) > 1:
           true_x, true_y = zip(*[(p[0], p[1]) for p in true_trajectory])
           true_traj_line.set_data(true_x, true_y)

        if len(estimated_trajectory) > 1:
            est_x, est_y = zip(*[(p[0], p[1]) for p in estimated_trajectory])
            est_traj_line.set_data(est_x, est_y)

        robot_dot.set_offsets([best_particle['pose'][:2]])
        particle_plot.set_offsets(np.array([p['pose'][:2] for p in particles]))

        # Keep robot centered in view
        window_size = 10.0  # meters
        half_window = window_size / 2.0
        x, y, theta = pose
        ax.set_xlim(x - half_window, x + half_window)
        ax.set_ylim(y - half_window, y + half_window)

        # Update observed landmarks from best particle
        visible_landmarks = [lm['mu'] for lm in best_particle['map'].values()]
        if visible_landmarks:
            observed_landmarks.set_offsets(np.array(visible_landmarks))
        else:
            observed_landmarks.set_offsets(np.empty((0, 2)))

        # === Clear previous ellipses ===
        [child.remove() for child in ax.patches[:]]
        # Clear previous text labels
        for label in reversed(ax.texts):
            label.remove()
        
        


        # === Draw uncertainty ellipses for each landmark ===
        for lm_id, lm in best_particle['map'].items():
            mu = lm['mu']
            sigma = lm['sigma']
            
            # Eigen decomposition to get ellipse shape
            vals, vecs = np.linalg.eigh(sigma)
            angle = np.degrees(np.arctan2(*vecs[:, 0][::-1]))
            width, height = 2 * np.sqrt(vals)  # 1-sigma ellipse

            ellipse = plt.matplotlib.patches.Ellipse(mu, width, height, angle=angle,
                                                edgecolor='green', facecolor='none', lw=1.5, alpha=0.7)
            ax.add_patch(ellipse)

            # Draw landmark ID below the landmark
            ax.text(mu[0], mu[1] - 0.2, f"id: {lm_id}", color='black', fontsize=9, ha='center', va='top')


        try:
            plt.draw()
            plt.pause(0.01)
        except Exception as e:
            rospy.logwarn(f"Plot update failed: {e}")
            break
        
        # Update for next iteration
        prev_pose = current_ros_pose.copy()
        step += 1
        
        # Log progress
        if step % 50 == 0:
            rospy.loginfo(f"FastSLAM step {step}/{num_steps} - Landmarks observed: {len(observed_landmarks_dict)}")
        
        rate.sleep()

    # Final results
    rospy.loginfo("FastSLAM simulation completed")
    
    # Plot final map
    best_particle = particles[highest_weight_particle_index]
    plot_final_map(best_particle, observed_landmarks_dict)

    # Print final statistics
    print("\n=== Final Map Estimate from Best Particle ===")
    
    for lm_id, lm in best_particle['map'].items():
        mu = lm['mu']
        print(f"Landmark {lm_id}:")
        print(f"  → Estimated: [{mu[0]:.2f}, {mu[1]:.2f}]")
    
    print(f"Total landmarks mapped: {len(best_particle['map'])}")
    print(f"Total unique landmarks observed: {len(observed_landmarks_dict)}")
    

    # === Kabsch-based SSE evaluation (with nearest-neighbor association) ===
    print("\n=== Landmark Estimation Error (Kabsch-Aligned SSE with NN Association) ===")

    # Collect estimated landmark positions
    estimated_landmarks = [lm['mu'] for lm in best_particle['map'].values()]
    estimated_landmarks = np.array(estimated_landmarks)

    if len(estimated_landmarks) >= 2 and len(gt_landmarks) >= 2:
        # Perform nearest-neighbor matching
        used_gt = set()
        matched_est = []
        matched_gt = []

        for est in estimated_landmarks:
            min_dist = float('inf')
            best_gt = None
            best_idx = -1
            for i, gt in enumerate(gt_landmarks):
                if i in used_gt:
                    continue
                dist = np.linalg.norm(est - gt)
                if dist < min_dist:
                    min_dist = dist
                    best_gt = gt
                    best_idx = i

            if best_gt is not None:
                used_gt.add(best_idx)
                matched_est.append(est)
                matched_gt.append(best_gt)

        matched_est = np.array(matched_est)
        matched_gt = np.array(matched_gt)

        if len(matched_est) >= 2:
            # Perform Kabsch alignment
            est_aligned, R, t = compute_kabsch_alignment(matched_est, matched_gt)
            sse = np.sum(np.square(est_aligned - matched_gt))
            rmse = np.sqrt(sse / len(matched_gt))

            for i, (aligned, gt) in enumerate(zip(est_aligned, matched_gt)):
                err = np.linalg.norm(aligned - gt)
                print(f"Pair {i}:")
                print(f"  → Aligned Estimate: [{aligned[0]:.2f}, {aligned[1]:.2f}]")
                print(f"  → Ground Truth:     [{gt[0]:.2f}, {gt[1]:.2f}]")
                print(f"  → Error: {err:.3f} m\n")

            print(f"Aligned Landmark Count: {len(matched_gt)}")
            print(f"SSE: {sse:.4f} m²")
            print(f"RMSE: {rmse:.4f} m")
        else:
            print("Not enough matched landmarks to perform reliable Kabsch alignment.")
    else:
        print("Insufficient landmark estimates or ground truth points for Kabsch evaluation.")


    rospy.loginfo("Keeping visualization open. Press Ctrl+C to exit.")
    # Keep the plot open
    plt.ioff()
    plt.show()



if __name__ == '__main__':
    try:
        main()
    except rospy.ROSInterruptException:
        rospy.loginfo("FastSLAM node interrupted")
    except KeyboardInterrupt:
        rospy.loginfo("FastSLAM node stopped by user")