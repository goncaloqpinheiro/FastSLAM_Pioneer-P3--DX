#!/usr/bin/env python3

import numpy as np
import rospy
from visualization_msgs.msg import Marker, MarkerArray
from geometry_msgs.msg import Point, Pose, Vector3
from std_msgs.msg import ColorRGBA, Header
from nav_msgs.msg import Path
from geometry_msgs.msg import PoseStamped
import tf2_ros
import tf2_geometry_msgs
from tf.transformations import quaternion_from_euler

class RVizPublisher:
    def __init__(self, frame_id="map"):
        self.frame_id = frame_id
        
        # Publishers
        self.particles_pub = rospy.Publisher('/fastslam/particles', MarkerArray, queue_size=1)
        self.landmarks_pub = rospy.Publisher('/fastslam/landmarks', MarkerArray, queue_size=1)
        self.trajectory_pub = rospy.Publisher('/fastslam/trajectory', Path, queue_size=1)
        self.robot_pub = rospy.Publisher('/fastslam/robot', Marker, queue_size=1)
        self.uncertainty_pub = rospy.Publisher('/fastslam/uncertainty', MarkerArray, queue_size=1)
        self.true_path_pub = rospy.Publisher("/fastslam/true_path", Path, queue_size=10)
        # Path message for trajectory
        self.path_msg = Path()
        self.path_msg.header.frame_id = self.frame_id
        
        rospy.loginfo("RViz publishers initialized")

    def publish_particles(self, particles):
        """Publish particle poses as arrows"""
        marker_array = MarkerArray()
        
        for i, particle in enumerate(particles):
            marker = Marker()
            marker.header.frame_id = self.frame_id
            marker.header.stamp = rospy.Time.now()
            marker.ns = "particles"
            marker.id = i
            marker.type = Marker.ARROW
            marker.action = Marker.ADD
            
            # Position
            marker.pose.position.x = particle['pose'][0]
            marker.pose.position.y = particle['pose'][1]
            marker.pose.position.z = 0.0
            
            # Orientation (quaternion from yaw)
            quat = quaternion_from_euler(0, 0, particle['pose'][2])
            marker.pose.orientation.x = quat[0]
            marker.pose.orientation.y = quat[1]
            marker.pose.orientation.z = quat[2]
            marker.pose.orientation.w = quat[3]
            
            # Scale
            marker.scale.x = 0.3  # Arrow length
            marker.scale.y = 0.05  # Arrow width
            marker.scale.z = 0.05  # Arrow height
            
            # Color based on weight
            weight = particle['weight']
            max_weight = max([p['weight'] for p in particles])
            normalized_weight = weight / max_weight if max_weight > 0 else 0.1
            
            marker.color.r = 0.5
            marker.color.g = 0.5
            marker.color.b = 1.0
            marker.color.a = 0.3 + 0.7 * normalized_weight  # More transparent for lower weights
            
            marker.lifetime = rospy.Duration(0.5)
            marker_array.markers.append(marker)
        
        self.particles_pub.publish(marker_array)

    def publish_landmarks(self, landmarks_map, best_particle_index=None):
        """Publish estimated landmarks as spheres with ID labels"""
        marker_array = MarkerArray()
        marker_id = 0
        
        for lm_id, landmark in landmarks_map.items():
            # Landmark sphere
            marker = Marker()
            marker.header.frame_id = self.frame_id
            marker.header.stamp = rospy.Time.now()
            marker.ns = "landmarks"
            marker.id = marker_id
            marker.type = Marker.SPHERE
            marker.action = Marker.ADD
            
            marker.pose.position.x = landmark['mu'][0]
            marker.pose.position.y = landmark['mu'][1]
            marker.pose.position.z = 0.5
            marker.pose.orientation.w = 1.0
            
            marker.scale.x = 0.3
            marker.scale.y = 0.3
            marker.scale.z = 0.3
            
            marker.color.r = 0.0
            marker.color.g = 1.0
            marker.color.b = 0.0
            marker.color.a = 1.0
            
            marker.lifetime = rospy.Duration(1.0)
            marker_array.markers.append(marker)
            marker_id += 1
            
            # Landmark ID text
            text_marker = Marker()
            text_marker.header.frame_id = self.frame_id
            text_marker.header.stamp = rospy.Time.now()
            text_marker.ns = "landmark_labels"
            text_marker.id = marker_id
            text_marker.type = Marker.TEXT_VIEW_FACING
            text_marker.action = Marker.ADD
            
            text_marker.pose.position.x = landmark['mu'][0]
            text_marker.pose.position.y = landmark['mu'][1]
            text_marker.pose.position.z = 0.8
            text_marker.pose.orientation.w = 1.0
            
            text_marker.scale.z = 0.3  # Text size
            
            text_marker.color.r = 1.0
            text_marker.color.g = 1.0
            text_marker.color.b = 1.0
            text_marker.color.a = 1.0
            
            text_marker.text = f"ID: {lm_id}"
            text_marker.lifetime = rospy.Duration(1.0)
            marker_array.markers.append(text_marker)
            marker_id += 1
        
        self.landmarks_pub.publish(marker_array)

    def publish_uncertainty_ellipses(self, landmarks_map):
        """Publish uncertainty ellipses for landmarks"""
        marker_array = MarkerArray()
        marker_id = 0
        
        for lm_id, landmark in landmarks_map.items():
            mu = landmark['mu']
            sigma = landmark['sigma']
            
            # Calculate ellipse parameters
            vals, vecs = np.linalg.eigh(sigma)
            angle = np.arctan2(vecs[1, 0], vecs[0, 0])
            width = 6 * np.sqrt(vals[0])  # 3-sigma ellipse
            height = 6 * np.sqrt(vals[1])
            
            marker = Marker()
            marker.header.frame_id = self.frame_id
            marker.header.stamp = rospy.Time.now()
            marker.ns = "uncertainty"
            marker.id = marker_id
            marker.type = Marker.CYLINDER
            marker.action = Marker.ADD
            
            marker.pose.position.x = mu[0]
            marker.pose.position.y = mu[1]
            marker.pose.position.z = 0.01  # Slightly above ground
            
            # Orientation from ellipse angle
            quat = quaternion_from_euler(0, 0, angle)
            marker.pose.orientation.x = quat[0]
            marker.pose.orientation.y = quat[1]
            marker.pose.orientation.z = quat[2]
            marker.pose.orientation.w = quat[3]
            
            marker.scale.x = width
            marker.scale.y = height
            marker.scale.z = 0.02  # Thin cylinder
            
            marker.color.r = 0.0
            marker.color.g = 1.0
            marker.color.b = 0.0
            marker.color.a = 0.3
            
            marker.lifetime = rospy.Duration(1.0)
            marker_array.markers.append(marker)
            marker_id += 1
        
        self.uncertainty_pub.publish(marker_array)

    def publish_trajectory(self, trajectory):
        """Publish estimated trajectory as a path"""
        self.path_msg.header.stamp = rospy.Time.now()
        
        # Add new pose to path
        if trajectory:
            latest_pose = trajectory[-1]
            pose_stamped = PoseStamped()
            pose_stamped.header.frame_id = self.frame_id
            pose_stamped.header.stamp = rospy.Time.now()
            
            pose_stamped.pose.position.x = latest_pose[0]
            pose_stamped.pose.position.y = latest_pose[1]
            pose_stamped.pose.position.z = 0.0
            
            quat = quaternion_from_euler(0, 0, latest_pose[2])
            pose_stamped.pose.orientation.x = quat[0]
            pose_stamped.pose.orientation.y = quat[1]
            pose_stamped.pose.orientation.z = quat[2]
            pose_stamped.pose.orientation.w = quat[3]
            
            self.path_msg.poses.append(pose_stamped)
            
            # Limit path length to avoid memory issues
            if len(self.path_msg.poses) > 1000:
                self.path_msg.poses = self.path_msg.poses[-500:]
        
        self.trajectory_pub.publish(self.path_msg)

    def publish_true_trajectory(self, trajectory):
        path = Path()
        path.header.stamp = rospy.Time.now()
        path.header.frame_id = "map"
        
        for pose in trajectory:
            pose_stamped = PoseStamped()
            pose_stamped.header.stamp = rospy.Time.now()
            pose_stamped.header.frame_id = "map"
            pose_stamped.pose.position.x = pose[0]
            pose_stamped.pose.position.y = pose[1]
            pose_stamped.pose.orientation.z = np.sin(pose[2] / 2.0)
            pose_stamped.pose.orientation.w = np.cos(pose[2] / 2.0)
            path.poses.append(pose_stamped)
        
        self.true_path_pub.publish(path)



    def publish_robot_pose(self, pose):
        """Publish current robot pose as a large arrow"""
        marker = Marker()
        marker.header.frame_id = self.frame_id
        marker.header.stamp = rospy.Time.now()
        marker.ns = "robot"
        marker.id = 0
        marker.type = Marker.ARROW
        marker.action = Marker.ADD
        
        marker.pose.position.x = pose[0]
        marker.pose.position.y = pose[1]
        marker.pose.position.z = 0.0
        
        quat = quaternion_from_euler(0, 0, pose[2])
        marker.pose.orientation.x = quat[0]
        marker.pose.orientation.y = quat[1]
        marker.pose.orientation.z = quat[2]
        marker.pose.orientation.w = quat[3]
        
        marker.scale.x = 0.8  # Arrow length
        marker.scale.y = 0.15  # Arrow width
        marker.scale.z = 0.15  # Arrow height
        
        marker.color.r = 1.0
        marker.color.g = 0.0
        marker.color.b = 0.0
        marker.color.a = 1.0
        
        marker.lifetime = rospy.Duration(0.5)
        self.robot_pub.publish(marker)

    def clear_markers(self):
        """Clear all markers from RViz"""
        # Clear particles
        marker_array = MarkerArray()
        marker = Marker()
        marker.action = Marker.DELETEALL
        marker_array.markers.append(marker)
        
        self.particles_pub.publish(marker_array)
        self.landmarks_pub.publish(marker_array)
        self.uncertainty_pub.publish(marker_array)
        
        # Clear robot marker
        marker = Marker()
        marker.action = Marker.DELETE
        marker.ns = "robot"
        marker.id = 0
        self.robot_pub.publish(marker)