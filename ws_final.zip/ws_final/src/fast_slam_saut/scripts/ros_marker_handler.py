#!/usr/bin/env python3

import numpy as np
import rospy
from geometry_msgs.msg import PoseArray
from std_msgs.msg import Int32MultiArray
import threading

class ROSMarkerHandler:
    def __init__(self, pose_handler):
        self.relative_poses = []  # relative marker poses
        self.ids = []             # marker IDs
        self.lock = threading.Lock()
        self.pose_handler = pose_handler
        
        rospy.Subscriber('/markers_pose', PoseArray, self.marker_pose_callback)
        rospy.Subscriber('/markers_id', Int32MultiArray, self.marker_id_callback)
        rospy.loginfo("Subscribed to /markers_pose and /markers_id topics")
    
    def marker_pose_callback(self, msg):
        with self.lock:
            self.relative_poses = msg.poses

    def marker_id_callback(self, msg):
        with self.lock:
            self.ids = msg.data

    def get_absolute_landmarks(self):
        """
        Transformação mais simples possível
        """
        with self.lock:
            if not self.pose_handler.is_pose_available():
                return []
            
            robot_pose = self.pose_handler.get_pose()
            abs_landmarks = []
            
            for i in range(min(len(self.relative_poses), len(self.ids))):
                rel_pose = self.relative_poses[i]
                lm_id = self.ids[i]
                
                # Camera coordinates
                x_cam = rel_pose.position.x  # lateral
                z_cam = rel_pose.position.z  # depth
                
                # Robot pose
                x_robot, y_robot, theta_robot = robot_pose
                
                # Direct transformation from camera to robot frame
                cos_theta = np.cos(theta_robot)
                sin_theta = np.sin(theta_robot)
                
                # Global coordinates
                x_global = x_robot + x_cam * cos_theta - z_cam * sin_theta
                y_global = y_robot + x_cam * sin_theta + z_cam * cos_theta
                
                abs_landmarks.append((lm_id, np.array([x_global, y_global])))
            
            return abs_landmarks